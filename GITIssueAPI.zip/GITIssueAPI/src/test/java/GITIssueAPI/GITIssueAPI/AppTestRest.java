package GITIssueAPI.GITIssueAPI;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class AppTestRest {
    private static final String BASE_URL = "https://gitlab.com/";
    private static final String API_TOKEN = "glpat-kmNR8QAw8GpxXz3QNLLe";
    private static final String project_id = "46614398";
   // private String issueId;
    

    private RequestSpecification requestSpec;

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = BASE_URL;
        RestAssured.basePath = "/api/v4";
        requestSpec = given()
                .header("Private-Token", API_TOKEN)
                .contentType(ContentType.JSON);
    }

    @Test(priority = 1)
    public void createIssueTest() {
        String createIssuePayload = "{\"title\": \"New Issue\", \"description\": \"This is a new issue.\"}";

        Response response = requestSpec
                .body(createIssuePayload)
                .when()
                .post("/projects/{project_id}/issues", "PROJECT_ID");

        response.then()
                .statusCode(201)
                .body("title", equalTo("New Issue"))
                .body("description", equalTo("This is a new issue."));
    }

    @Test(priority = 2)
    public void getIssueTest() {
        Response response = requestSpec
                .when()
                .get("/projects/{project_id}/issues/{issue_id}", "PROJECT_ID", "ISSUE_ID");

        response.then()
                .statusCode(200)
                .body("title", equalTo("New Issue"))
                .body("description", equalTo("This is a new issue."));
    }

    @Test(priority = 3)
    public void updateIssueTest() {
        String updateIssuePayload = "{\"title\": \"Updated Issue\", \"description\": \"This issue has been updated.\"}";

        Response response = requestSpec
                .body(updateIssuePayload)
                .when()
                .put("/projects/{project_id}/issues/{issue_id}", "PROJECT_ID", "ISSUE_ID");

        response.then()
                .statusCode(200)
                .body("title", equalTo("Updated Issue"))
                .body("description", equalTo("This issue has been updated."));
    }

    @Test(priority = 4)
    public void deleteIssueTest() {
        Response response = requestSpec
                .when()
                .delete("/projects/{project_id}/issues/{issue_id}", "PROJECT_ID", "ISSUE_ID");

        response.then()
                .statusCode(204);
    }

    @Test(priority = 5)
    public void getNonExistentIssueTest() {
        Response response = requestSpec
                .when()
                .get("/projects/{project_id}/issues/{issue_id}", "PROJECT_ID", "NON_EXISTENT_ISSUE_ID");

        response.then()
                .statusCode(404)
                .body("message", equalTo("404 Issue Not Found"));
    }
}
