package GITIssueAPI.GITIssueAPI;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class GIT_Crud {
    private static final String BASE_URL = "https://gitlab.com/";
    private static final String API_TOKEN = "glpat-kmNR8QAw8GpxXz3QNLLe";
    private static final String PROJECT_ID = "46614398";
    public String issueId;
    //setup code 
    @BeforeTest
    public void setup() {
        RestAssured.baseURI = BASE_URL;
        RestAssured.basePath = "/api/v4";
    }
    // code for create an issue in Git lab with minimum details
    @Test(priority = 1)
    public void createIssue() throws InterruptedException {
        String issueTitle = "API testing issue111";
        String issueDescription = "This is a new issue.";

        Response response = given()
                .header("Private-Token", API_TOKEN)
                .contentType(ContentType.JSON)
                .body("{\"title\": \"" + issueTitle + "\", \"description\": \"" + issueDescription + "\"}")
                .when()
                .post("/projects/" + PROJECT_ID + "/issues");

        response.then()
                .statusCode(201)
                .log().body();
        //getting the issue id future usage
        issueId = response.jsonPath().getString("iid");
        System.out.println("Issue ID: " + issueId);

    }
    // code for verify issue is created or not
    @Test(priority = 2)
    public void getIssueTest() {
        Response response =  given()
        		.header("Private-Token", API_TOKEN)
                .contentType(ContentType.JSON)
                .when()
                .get("/projects/"+PROJECT_ID+"/issues/"+issueId);
        	
        response.then()
                .statusCode(200)
                .log().body();
        issueId = response.jsonPath().getString("iid");
        System.out.println("Issue ID: " + issueId);
    }
    // code for update the issue and verifying status code
    @Test(priority = 3)
    public void updateIssue() {
        String updatedTitle = "Updated Issue";
        String updatedDescription = "This issue has been updated.";

        Response response = given()
                .header("Private-Token", API_TOKEN)
                .contentType(ContentType.JSON)
                .body("{\"title\": \"" + updatedTitle + "\", \"description\": \"" + updatedDescription + "\"}")
                .when()
                .put("/projects/" + PROJECT_ID + "/issues/" + issueId );

        response.then()
                .statusCode(200)
                .log().body();
    }
 // code for delete the issue and verifying status code
    @Test(priority = 4)
    public void deleteIssue() {
        Response response = given()
                .header("Private-Token", API_TOKEN)
                .when()
                .delete("/projects/" + PROJECT_ID + "/issues/" + issueId);

        response.then()
                .statusCode(204)
                .log().all();
        System.out.println("Deleted Issue ID is : " + issueId);
    }
}

